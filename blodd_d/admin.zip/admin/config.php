<?php

$conn = mysqli_connect('localhost','root','','blood_d');

?>